"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import type { User } from "@/types/user"

interface AuthContextType {
  user: User | null
  login: (username: string) => Promise<boolean>
  logout: () => void
  isLoading: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  // Check for existing session on mount
  useEffect(() => {
    const storedUser = localStorage.getItem("myscol_user")
    if (storedUser) {
      setUser(JSON.parse(storedUser))
    }
    setIsLoading(false)
  }, [])

  // Mock login function - in a real app, this would call an API
  const login = async (username: string): Promise<boolean> => {
    setIsLoading(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Validate username format (e.g., tch_14ec_876)
    const isValidFormat = /^[a-z]{3}_\d{2}[a-z]{2}_\d{3}$/.test(username)

    if (!isValidFormat) {
      setIsLoading(false)
      return false
    }

    // Determine role based on username prefix
    let role: "student" | "teacher" | "parent" | "admin"
    const prefix = username.substring(0, 3)

    switch (prefix) {
      case "tch":
        role = "teacher"
        break
      case "prt":
        role = "parent"
        break
      case "adm":
        role = "admin"
        break
      default:
        role = "student"
    }

    // Extract student ID from username for students and parents
    const studentId = role === "student" || role === "parent" ? username.substring(username.length - 3) : undefined

    // Create user object with additional fields based on role
    const newUser: User = {
      id: `user_${Date.now()}`,
      username,
      role,
      name: role === "student" ? "Rafael DUPOND" : `User ${username.substring(4, 8)}`,
      studentId,
      class: role === "student" ? "3EME" : undefined,
      section: role === "student" ? "3ème LV2 Allemand" : undefined,
      assignedClasses: role === "teacher" ? ["3EME"] : undefined,
      children: role === "parent" ? [{ id: "child_1", name: "Rafael DUPOND" }] : undefined,
    }

    setUser(newUser)
    localStorage.setItem("myscol_user", JSON.stringify(newUser))
    setIsLoading(false)
    return true
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem("myscol_user")
  }

  return <AuthContext.Provider value={{ user, login, logout, isLoading }}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

