import type { User } from "@/types/user"

// Sample data for users
export const usersData: User[] = [
  {
    id: "user_1",
    name: "DUPOND Rafael",
    username: "std_rd14_876",
    email: "rafael.dupond@student.myscol.net",
    role: "student",
    studentId: "876",
    class: "3EME",
    section: "3ème LV2 Allemand",
  },
  {
    id: "user_2",
    name: "MARTIN Sophie",
    username: "std_sm22_123",
    email: "sophie.martin@student.myscol.net",
    role: "student",
    studentId: "123",
    class: "3EME",
    section: "3ème LV2 Espagnol",
  },
  {
    id: "user_3",
    name: "PONOMAROVA Irina",
    username: "tch_ip45_234",
    email: "irina.ponomarova@teacher.myscol.net",
    role: "teacher",
    assignedClasses: ["3EME", "4EME"],
    subjects: ["Français"],
  },
  {
    id: "user_4",
    name: "MARTRON Pierre",
    username: "tch_pm33_567",
    email: "pierre.martron@teacher.myscol.net",
    role: "teacher",
    assignedClasses: ["3EME", "2NDE"],
    subjects: ["Histoire Géographie"],
  },
  {
    id: "user_5",
    name: "DUPOND Christine",
    username: "prt_cd19_345",
    email: "christine.dupond@parent.myscol.net",
    role: "parent",
    children: [{ id: "user_1", name: "DUPOND Rafael" }],
  },
  {
    id: "user_6",
    name: "MARTIN Jean",
    username: "prt_jm27_678",
    email: "jean.martin@parent.myscol.net",
    role: "parent",
    children: [{ id: "user_2", name: "MARTIN Sophie" }],
  },
]

