"use client"

import type React from "react"

import { useEffect } from "react"
import { useRouter, usePathname } from "next/navigation"
import { useAuth } from "@/contexts/auth-context"
import { Loader2 } from "lucide-react"

interface ProtectedRouteProps {
  children: React.ReactNode
  allowedRoles?: Array<"student" | "teacher" | "parent" | "admin">
}

export function ProtectedRoute({ children, allowedRoles }: ProtectedRouteProps) {
  const { user, isLoading } = useAuth()
  const router = useRouter()
  const pathname = usePathname()

  useEffect(() => {
    // Skip auth check for public pages
    if (pathname === "/login" || pathname === "/") return

    // If finished loading and no user, redirect to login
    if (!isLoading && !user) {
      router.push("/login")
    }

    // If user exists but doesn't have the required role
    if (!isLoading && user && allowedRoles && !allowedRoles.includes(user.role)) {
      router.push("/unauthorized")
    }

    // Admin-specific routes
    if (pathname.startsWith("/admin") && (!user || user.role !== "admin")) {
      router.push("/unauthorized")
    }
  }, [user, isLoading, router, pathname, allowedRoles])

  // Show loading state
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="flex flex-col items-center gap-2">
          <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
          <p className="text-sm text-muted-foreground">Chargement...</p>
        </div>
      </div>
    )
  }

  // If on login page or public page, or user is authenticated with correct role, render children
  if (pathname === "/login" || pathname === "/" || (user && (!allowedRoles || allowedRoles.includes(user.role)))) {
    // For admin routes, ensure user is admin
    if (pathname.startsWith("/admin") && (!user || user.role !== "admin")) {
      return null
    }

    return <>{children}</>
  }

  // Otherwise render nothing while redirecting
  return null
}

