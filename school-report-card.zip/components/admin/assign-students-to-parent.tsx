"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import type { User } from "@/types/user"

interface AssignStudentsToParentProps {
  parent: User
  students: User[]
  onAssign: (parentId: string, studentIds: string[]) => void
}

export function AssignStudentsToParent({ parent, students, onAssign }: AssignStudentsToParentProps) {
  const [selectedStudents, setSelectedStudents] = useState<string[]>(parent.children?.map((child) => child.id) || [])
  const [open, setOpen] = useState(false)

  const handleSubmit = () => {
    onAssign(parent.id, selectedStudents)
    setOpen(false)
  }

  const handleCheckboxChange = (studentId: string, checked: boolean) => {
    if (checked) {
      setSelectedStudents((prev) => [...prev, studentId])
    } else {
      setSelectedStudents((prev) => prev.filter((id) => id !== studentId))
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          Associer des élèves
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Associer des élèves</DialogTitle>
          <DialogDescription>Sélectionnez les élèves à associer au parent {parent.name}.</DialogDescription>
        </DialogHeader>
        <div className="py-4 space-y-4">
          {students.length === 0 ? (
            <p className="text-muted-foreground">Aucun élève disponible.</p>
          ) : (
            students.map((student) => (
              <div key={student.id} className="flex items-center space-x-2">
                <Checkbox
                  id={`student-${student.id}`}
                  checked={selectedStudents.includes(student.id)}
                  onCheckedChange={(checked) => handleCheckboxChange(student.id, checked as boolean)}
                />
                <Label htmlFor={`student-${student.id}`} className="flex-1">
                  {student.name}
                  <span className="text-xs text-muted-foreground ml-2">({student.class})</span>
                </Label>
              </div>
            ))
          )}
        </div>
        <DialogFooter>
          <Button type="button" variant="outline" onClick={() => setOpen(false)}>
            Annuler
          </Button>
          <Button type="button" onClick={handleSubmit}>
            Associer
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

