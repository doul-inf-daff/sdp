"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { UsersList } from "@/components/admin/users-list"
import { CreateUserForm } from "@/components/admin/create-user-form"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"
import type { User } from "@/types/user"
import { usersData } from "@/data/users-data"

export function UsersManagement() {
  const [activeTab, setActiveTab] = useState("students")
  const [users, setUsers] = useState<User[]>(usersData)
  const [showCreateForm, setShowCreateForm] = useState(false)

  const handleCreateUser = (newUser: User) => {
    setUsers([...users, newUser])
    setShowCreateForm(false)
  }

  const filteredUsers = users.filter((user) => user.role === activeTab.slice(0, -1))

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium">Utilisateurs ({filteredUsers.length})</h3>
        <Button onClick={() => setShowCreateForm(true)} className="flex items-center gap-2" disabled={showCreateForm}>
          <Plus className="h-4 w-4" />
          Ajouter un utilisateur
        </Button>
      </div>

      {showCreateForm ? (
        <CreateUserForm
          userType={activeTab.slice(0, -1) as "student" | "teacher" | "parent" | "admin"}
          onSubmit={handleCreateUser}
          onCancel={() => setShowCreateForm(false)}
          existingUsers={users}
        />
      ) : (
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="grid grid-cols-3 md:w-[400px]">
            <TabsTrigger value="students">Élèves</TabsTrigger>
            <TabsTrigger value="teachers">Enseignants</TabsTrigger>
            <TabsTrigger value="parents">Parents</TabsTrigger>
          </TabsList>

          <TabsContent value="students">
            <UsersList users={filteredUsers} type="student" />
          </TabsContent>

          <TabsContent value="teachers">
            <UsersList users={filteredUsers} type="teacher" />
          </TabsContent>

          <TabsContent value="parents">
            <UsersList users={filteredUsers} type="parent" />
          </TabsContent>
        </Tabs>
      )}
    </div>
  )
}

