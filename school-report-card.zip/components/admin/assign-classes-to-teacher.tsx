"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import type { User } from "@/types/user"

// Sample data for classes
const allClasses = ["6EME", "5EME", "4EME", "3EME", "2NDE", "1ERE", "TERM"]

interface AssignClassesToTeacherProps {
  teacher: User
  onAssign: (teacherId: string, classes: string[]) => void
}

export function AssignClassesToTeacher({ teacher, onAssign }: AssignClassesToTeacherProps) {
  const [selectedClasses, setSelectedClasses] = useState<string[]>(teacher.assignedClasses || [])
  const [open, setOpen] = useState(false)

  const handleSubmit = () => {
    onAssign(teacher.id, selectedClasses)
    setOpen(false)
  }

  const handleCheckboxChange = (className: string, checked: boolean) => {
    if (checked) {
      setSelectedClasses((prev) => [...prev, className])
    } else {
      setSelectedClasses((prev) => prev.filter((cls) => cls !== className))
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          Assigner des classes
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Assigner des classes</DialogTitle>
          <DialogDescription>Sélectionnez les classes à assigner à l'enseignant {teacher.name}.</DialogDescription>
        </DialogHeader>
        <div className="py-4 grid grid-cols-2 gap-4">
          {allClasses.map((cls) => (
            <div key={cls} className="flex items-center space-x-2">
              <Checkbox
                id={`class-${cls}`}
                checked={selectedClasses.includes(cls)}
                onCheckedChange={(checked) => handleCheckboxChange(cls, checked as boolean)}
              />
              <Label htmlFor={`class-${cls}`}>{cls}</Label>
            </div>
          ))}
        </div>
        <DialogFooter>
          <Button type="button" variant="outline" onClick={() => setOpen(false)}>
            Annuler
          </Button>
          <Button type="button" onClick={handleSubmit}>
            Assigner
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

