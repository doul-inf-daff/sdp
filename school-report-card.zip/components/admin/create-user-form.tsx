"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { CheckCircle2, X } from "lucide-react"
import type { User } from "@/types/user"

// Sample data for dropdowns
const classes = ["6EME", "5EME", "4EME", "3EME", "2NDE", "1ERE", "TERM"]
const sections = [
  "6ème Standard",
  "5ème LV2 Espagnol",
  "4ème LV2 Allemand",
  "3ème LV2 Allemand",
  "2nde Sciences",
  "1ère Sciences",
  "Terminale Sciences",
]

interface CreateUserFormProps {
  userType: "student" | "teacher" | "parent" | "admin"
  onSubmit: (user: User) => void
  onCancel: () => void
  existingUsers: User[]
}

export function CreateUserForm({ userType, onSubmit, onCancel, existingUsers }: CreateUserFormProps) {
  const [formValues, setFormValues] = useState({
    firstName: "",
    lastName: "",
    email: "",
    class: "",
    section: "",
    assignedClasses: [],
    children: [],
  })
  const [generatedUsername, setGeneratedUsername] = useState("")
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState("")

  // Generate a unique username based on the user type and form values
  const generateUsername = () => {
    if (!formValues.firstName || !formValues.lastName) {
      setError("Veuillez saisir le nom et prénom pour générer un identifiant")
      return
    }

    // Prefix based on user type
    const prefix =
      userType === "student" ? "std" : userType === "teacher" ? "tch" : userType === "parent" ? "prt" : "adm"

    // Middle part based on first and last name initials + random 2 digit number
    const firstInitial = formValues.firstName.charAt(0).toLowerCase()
    const lastInitial = formValues.lastName.charAt(0).toLowerCase()
    const randomNum = Math.floor(Math.random() * 90) + 10 // 10-99

    // Suffix - random 3 digit number
    const randomSuffix = Math.floor(Math.random() * 900) + 100 // 100-999

    let username = `${prefix}_${firstInitial}${lastInitial}${randomNum}_${randomSuffix}`

    // Check if username already exists and regenerate if needed
    while (existingUsers.some((user) => user.username === username)) {
      const newRandomNum = Math.floor(Math.random() * 90) + 10
      const newRandomSuffix = Math.floor(Math.random() * 900) + 100
      username = `${prefix}_${firstInitial}${lastInitial}${newRandomNum}_${newRandomSuffix}`
    }

    setGeneratedUsername(username)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!generatedUsername) {
      setError("Veuillez générer un identifiant unique")
      return
    }

    // Create a new user object
    const newUser: User = {
      id: `user_${Date.now()}`,
      name: `${formValues.lastName} ${formValues.firstName}`,
      username: generatedUsername,
      email: formValues.email,
      role: userType,
    }

    // Add role-specific properties
    if (userType === "student") {
      newUser.class = formValues.class
      newUser.section = formValues.section
    } else if (userType === "teacher") {
      newUser.assignedClasses = formValues.assignedClasses
    } else if (userType === "parent") {
      newUser.children = [] // Would be populated from a real form
    }

    setSuccess(true)
    setTimeout(() => {
      onSubmit(newUser)
    }, 1000)
  }

  const handleInputChange = (field: string, value: string) => {
    setFormValues((prev) => ({ ...prev, [field]: value }))
  }

  const getFormTitle = () => {
    switch (userType) {
      case "student":
        return "Ajouter un élève"
      case "teacher":
        return "Ajouter un enseignant"
      case "parent":
        return "Ajouter un parent"
      case "admin":
        return "Ajouter un administrateur"
    }
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>{getFormTitle()}</CardTitle>
            <CardDescription>Créez un nouvel utilisateur et générez un identifiant unique.</CardDescription>
          </div>
          <Button variant="ghost" size="sm" onClick={onCancel}>
            <X className="h-5 w-5" />
          </Button>
        </div>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="lastName">Nom</Label>
              <Input
                id="lastName"
                value={formValues.lastName}
                onChange={(e) => handleInputChange("lastName", e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="firstName">Prénom</Label>
              <Input
                id="firstName"
                value={formValues.firstName}
                onChange={(e) => handleInputChange("firstName", e.target.value)}
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              value={formValues.email}
              onChange={(e) => handleInputChange("email", e.target.value)}
              required
            />
          </div>

          {userType === "student" && (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="class">Classe</Label>
                  <Select onValueChange={(value) => handleInputChange("class", value)} required>
                    <SelectTrigger>
                      <SelectValue placeholder="Sélectionner une classe" />
                    </SelectTrigger>
                    <SelectContent>
                      {classes.map((cls) => (
                        <SelectItem key={cls} value={cls}>
                          {cls}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="section">Section</Label>
                  <Select onValueChange={(value) => handleInputChange("section", value)} required>
                    <SelectTrigger>
                      <SelectValue placeholder="Sélectionner une section" />
                    </SelectTrigger>
                    <SelectContent>
                      {sections.map((section) => (
                        <SelectItem key={section} value={section}>
                          {section}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </>
          )}

          {userType === "teacher" && (
            <div className="space-y-2">
              <Label>Classes assignées</Label>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                {classes.map((cls) => (
                  <div key={cls} className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id={`class-${cls}`}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setFormValues((prev) => ({
                            ...prev,
                            assignedClasses: [...prev.assignedClasses, cls],
                          }))
                        } else {
                          setFormValues((prev) => ({
                            ...prev,
                            assignedClasses: prev.assignedClasses.filter((c) => c !== cls),
                          }))
                        }
                      }}
                    />
                    <label htmlFor={`class-${cls}`}>{cls}</label>
                  </div>
                ))}
              </div>
            </div>
          )}

          {userType === "parent" && (
            <div className="space-y-2">
              <Label>Enfants</Label>
              <p className="text-sm text-muted-foreground">
                Les enfants pourront être associés après la création du compte.
              </p>
            </div>
          )}

          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <Label htmlFor="username">Identifiant</Label>
              <Button type="button" variant="outline" size="sm" onClick={generateUsername}>
                Générer
              </Button>
            </div>
            <Input id="username" value={generatedUsername} readOnly className="font-mono" />
            <p className="text-xs text-muted-foreground">
              L'identifiant est généré automatiquement selon le format requis.
            </p>
          </div>

          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {success && (
            <Alert className="bg-green-50 text-green-800 border-green-200">
              <CheckCircle2 className="h-4 w-4 text-green-600" />
              <AlertDescription>Utilisateur créé avec succès!</AlertDescription>
            </Alert>
          )}
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button type="button" variant="outline" onClick={onCancel}>
            Annuler
          </Button>
          <Button type="submit" disabled={success}>
            {success ? "Utilisateur créé" : "Créer l'utilisateur"}
          </Button>
        </CardFooter>
      </form>
    </Card>
  )
}

