"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { useAuth } from "@/contexts/auth-context"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { LogOut, Menu, User } from "lucide-react"

export function Navbar() {
  const { user, logout } = useAuth()
  const pathname = usePathname()

  // Don't show navbar on login page
  if (pathname === "/login") return null

  return (
    <header className="border-b bg-white">
      <div className="container flex h-16 items-center justify-between px-4">
        <div className="flex items-center gap-2">
          <Link href="/" className="flex items-center">
            <span className="text-2xl font-bold text-blue-600">MyScol</span>
          </Link>
        </div>

        <nav className="hidden md:flex items-center gap-6">
          <Link
            href="/dashboard"
            className={`text-sm font-medium ${pathname === "/dashboard" ? "text-blue-600" : "text-gray-600 hover:text-blue-600"}`}
          >
            Tableau de bord
          </Link>
          <Link
            href="/reports"
            className={`text-sm font-medium ${pathname.startsWith("/reports") ? "text-blue-600" : "text-gray-600 hover:text-blue-600"}`}
          >
            Bulletins
          </Link>
          {user?.role === "teacher" && (
            <Link
              href="/classes"
              className={`text-sm font-medium ${pathname.startsWith("/classes") ? "text-blue-600" : "text-gray-600 hover:text-blue-600"}`}
            >
              Classes
            </Link>
          )}
          {user?.role === "admin" && (
            <Link
              href="/admin"
              className={`text-sm font-medium ${pathname.startsWith("/admin") ? "text-blue-600" : "text-gray-600 hover:text-blue-600"}`}
            >
              Administration
            </Link>
          )}
        </nav>

        <div className="flex items-center gap-4">
          {user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="gap-2">
                  <User className="h-4 w-4" />
                  <span className="hidden md:inline">{user.name || user.username}</span>
                  {user.role === "admin" && (
                    <span className="bg-blue-100 text-blue-800 text-xs px-2 py-0.5 rounded hidden md:inline">
                      Admin
                    </span>
                  )}
                  {user.role === "teacher" && (
                    <span className="bg-green-100 text-green-800 text-xs px-2 py-0.5 rounded hidden md:inline">
                      Enseignant
                    </span>
                  )}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Mon compte</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem>
                  <Link href="/profile" className="flex w-full">
                    Profil
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Link href="/settings" className="flex w-full">
                    Paramètres
                  </Link>
                </DropdownMenuItem>
                {user.role === "admin" && (
                  <DropdownMenuItem>
                    <Link href="/admin" className="flex w-full">
                      Administration
                    </Link>
                  </DropdownMenuItem>
                )}
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={logout} className="text-red-600">
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Déconnexion</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Button asChild size="sm">
              <Link href="/login">Connexion</Link>
            </Button>
          )}

          <DropdownMenu>
            <DropdownMenuTrigger asChild className="md:hidden">
              <Button variant="ghost" size="icon">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Menu</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="md:hidden">
              <DropdownMenuItem>
                <Link href="/dashboard" className="flex w-full">
                  Tableau de bord
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Link href="/reports" className="flex w-full">
                  Bulletins
                </Link>
              </DropdownMenuItem>
              {user?.role === "teacher" && (
                <DropdownMenuItem>
                  <Link href="/classes" className="flex w-full">
                    Classes
                  </Link>
                </DropdownMenuItem>
              )}
              {user?.role === "admin" && (
                <DropdownMenuItem>
                  <Link href="/admin" className="flex w-full">
                    Administration
                  </Link>
                </DropdownMenuItem>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  )
}

