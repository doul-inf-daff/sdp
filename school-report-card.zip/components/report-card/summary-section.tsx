interface SummarySectionProps {
  average: number
  absences: number
}

export function SummarySection({ average, absences }: SummarySectionProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 border-t">
      <div className="md:border-r p-3 md:p-4 flex justify-between items-center bg-slate-700 text-white">
        <span className="font-semibold text-sm md:text-base">Moyenne générale</span>
      </div>
      <div className="p-3 md:p-4 flex justify-between items-center bg-slate-700 text-white border-t md:border-t-0">
        <span className="font-semibold text-sm md:text-base">Nombre de demi-journée d'absence</span>
      </div>
      <div className="md:border-r p-3 md:p-4 text-center font-bold border-t">{average.toFixed(2)}</div>
      <div className="p-3 md:p-4 text-center font-bold border-t">{absences}</div>
    </div>
  )
}

