import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import type { Subject } from "@/types/report-card"

interface GradesTableProps {
  subjects: Subject[]
}

export function GradesTable({ subjects }: GradesTableProps) {
  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader className="bg-slate-700 text-white">
          <TableRow>
            <TableHead className="w-1/4 py-3 whitespace-nowrap">Matières</TableHead>
            <TableHead className="w-1/12 text-center py-3 whitespace-nowrap">Moy /20</TableHead>
            <TableHead colSpan={3} className="text-center py-3 whitespace-nowrap">
              Classe
            </TableHead>
            <TableHead className="w-1/2 py-3">Appréciations</TableHead>
          </TableRow>
          <TableRow className="bg-slate-700 text-white">
            <TableHead></TableHead>
            <TableHead></TableHead>
            <TableHead className="text-center py-2 whitespace-nowrap">Min</TableHead>
            <TableHead className="text-center py-2 whitespace-nowrap">Max</TableHead>
            <TableHead className="text-center py-2 whitespace-nowrap">Moy</TableHead>
            <TableHead></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {subjects.map((subject, index) => (
            <TableRow key={index} className={index % 2 === 0 ? "bg-gray-100" : ""}>
              <TableCell className="font-medium">
                <span className="whitespace-nowrap">
                  {subject.name} <sup>({subject.coefficient})</sup>
                </span>
                <div className="text-xs md:text-sm italic">
                  {subject.teacher.title} {subject.teacher.name}
                </div>
              </TableCell>
              <TableCell className="text-center">{subject.studentGrade.toFixed(2)}</TableCell>
              <TableCell className="text-center">{subject.classMin.toFixed(2)}</TableCell>
              <TableCell className="text-center">{subject.classMax.toFixed(2)}</TableCell>
              <TableCell className="text-center">{subject.classAverage.toFixed(2)}</TableCell>
              <TableCell className="text-xs md:text-sm">{subject.comments}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>

      <div className="text-xs p-2 border-t">
        <sup>(1)</sup> : Coefficient de la matière
      </div>
    </div>
  )
}

