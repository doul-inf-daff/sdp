"use client"

import { Button } from "@/components/ui/button"
import type { ReportCardData } from "@/types/report-card"
import { downloadReportPDF } from "@/services/pdf-service"
import { Download } from "lucide-react"
import { useState } from "react"

interface DownloadButtonProps {
  data: ReportCardData
}

export function DownloadButton({ data }: DownloadButtonProps) {
  const [isDownloading, setIsDownloading] = useState(false)

  const handleDownload = async () => {
    setIsDownloading(true)

    try {
      // Dynamically import jsPDF only when needed
      const { jsPDF } = await import("jspdf")
      await import("jspdf-autotable")

      // Download the PDF
      downloadReportPDF(data)
    } catch (error) {
      console.error("Error generating PDF:", error)
    } finally {
      setIsDownloading(false)
    }
  }

  return (
    <Button onClick={handleDownload} disabled={isDownloading} className="flex items-center gap-2">
      <Download className="h-4 w-4" />
      {isDownloading ? "Génération en cours..." : "Télécharger le bulletin"}
    </Button>
  )
}

