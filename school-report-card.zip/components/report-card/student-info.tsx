import Image from "next/image"
import type { Student } from "@/types/report-card"

interface StudentInfoProps {
  student: Student
}

export function StudentInfo({ student }: StudentInfoProps) {
  return (
    <div className="flex flex-col md:flex-row md:justify-between p-4 border-b">
      <div className="space-y-2 md:space-y-4 mb-4 md:mb-0">
        <div className="flex gap-2">
          <p className="font-bold">Nom :</p>
          <p>
            {student.lastName} {student.firstName}
          </p>
        </div>
        <div className="flex gap-2">
          <p className="font-bold">Classe :</p>
          <p>
            {student.class} ({student.classSize} élève{student.classSize > 1 ? "s" : ""})
          </p>
        </div>
      </div>
      <div className="flex flex-col md:items-end">
        <div className="flex gap-2 mb-4">
          <p className="font-bold">Section :</p>
          <p>
            {student.section} ({student.sectionSize} élève{student.sectionSize > 1 ? "s" : ""})
          </p>
        </div>
        <div className="w-20 h-20 md:w-24 md:h-24 relative self-center md:self-end">
          <Image
            src={student.avatarUrl || "/placeholder.svg"}
            alt="Student Avatar"
            width={96}
            height={96}
            className="object-contain"
          />
        </div>
      </div>
    </div>
  )
}

