import Image from "next/image"
import type { ReportCardData } from "@/types/report-card"

interface HeaderProps {
  data: Pick<
    ReportCardData,
    "schoolName" | "schoolAddress" | "schoolCity" | "schoolZip" | "schoolPhone" | "schoolWebsite"
  >
}

export function ReportCardHeader({ data }: HeaderProps) {
  return (
    <div className="flex flex-col md:flex-row md:justify-between md:items-center p-4 border-b">
      <div className="flex items-center gap-2 mb-4 md:mb-0">
        <div className="w-12 h-12 relative">
          <Image
            src="/placeholder.svg?height=48&width=48"
            alt="MyScol Logo"
            width={48}
            height={48}
            className="object-contain"
          />
        </div>
        <h1 className="text-2xl font-bold text-blue-500">MyScol</h1>
      </div>
      <div className="text-left md:text-right text-sm">
        <p className="font-semibold">{data.schoolName}</p>
        <p>{data.schoolAddress}</p>
        <p>
          {data.schoolZip} {data.schoolCity}
        </p>
        <p>
          Tél: {data.schoolPhone} - Site: {data.schoolWebsite}
        </p>
      </div>
    </div>
  )
}

