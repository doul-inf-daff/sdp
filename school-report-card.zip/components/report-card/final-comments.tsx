interface FinalCommentsProps {
  mention: string
  comments: string
}

export function FinalComments({ mention, comments }: FinalCommentsProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 border-t">
      <div className="md:border-r p-3 md:p-4 flex justify-between items-center bg-slate-700 text-white">
        <span className="font-semibold text-sm md:text-base">Mention</span>
      </div>
      <div className="p-3 md:p-4 flex justify-between items-center bg-slate-700 text-white border-t md:border-t-0">
        <span className="font-semibold text-sm md:text-base">Appréciations du conseil de classe</span>
      </div>
      <div className="md:border-r p-3 md:p-4 text-center font-bold border-t">{mention}</div>
      <div className="p-3 md:p-4 text-xs md:text-sm border-t">{comments}</div>
    </div>
  )
}

