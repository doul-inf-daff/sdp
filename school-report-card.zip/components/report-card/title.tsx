interface TitleProps {
  trimester: number
  schoolYear: string
}

export function ReportCardTitle({ trimester, schoolYear }: TitleProps) {
  const trimesterText = trimester === 1 ? "1ER" : trimester === 2 ? "2ÈME" : trimester === 3 ? "3ÈME" : `${trimester}E`

  return (
    <div className="text-center py-4 md:py-6 border-b px-2">
      <h2 className="text-xl md:text-2xl font-bold">BULLETIN DE NOTES DU {trimesterText} TRIMESTRE</h2>
      <p className="mt-1 text-sm md:text-base">Année scolaire: {schoolYear}</p>
    </div>
  )
}

