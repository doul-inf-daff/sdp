import type { ReportCardData } from "@/types/report-card"
import { ReportCardHeader } from "./header"
import { ReportCardTitle } from "./title"
import { StudentInfo } from "./student-info"
import { GradesTable } from "./grades-table"
import { SummarySection } from "./summary-section"
import { FinalComments } from "./final-comments"
import { DownloadButton } from "./download-button"

interface ReportCardProps {
  data: ReportCardData
}

export function ReportCard({ data }: ReportCardProps) {
  return (
    <div className="max-w-4xl mx-auto bg-white shadow-md">
      <ReportCardHeader data={data} />
      <div className="flex justify-between items-center px-4 py-2 border-b">
        <ReportCardTitle trimester={data.trimester} schoolYear={data.schoolYear} />
        <div className="hidden md:block">
          <DownloadButton data={data} />
        </div>
      </div>
      <StudentInfo student={data.student} />
      <GradesTable subjects={data.subjects} />
      <SummarySection average={data.generalAverage} absences={data.absences} />
      <FinalComments mention={data.mention} comments={data.councilComments} />
      <div className="md:hidden p-4 border-t">
        <DownloadButton data={data} />
      </div>
    </div>
  )
}

