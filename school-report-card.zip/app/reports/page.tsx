"use client"

import { useAuth } from "@/contexts/auth-context"
import Link from "next/link"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { FileText, Download } from "lucide-react"
import { useEffect, useState } from "react"
import { sampleReportData } from "@/data/sample-report-data"
import { downloadReportPDF } from "@/services/pdf-service"

interface ReportItem {
  id: string
  trimester: number
  year: string
  date: string
  studentId: string
}

export default function ReportsPage() {
  const { user } = useAuth()
  const [isDownloading, setIsDownloading] = useState<string | null>(null)

  // Sample data - in a real app, this would come from an API
  const allReports: ReportItem[] = [
    { id: "12345", trimester: 1, year: "2021-2022", date: "15/12/2021", studentId: "876" },
    { id: "12346", trimester: 2, year: "2021-2022", date: "15/03/2022", studentId: "876" },
    { id: "12347", trimester: 3, year: "2021-2022", date: "15/06/2022", studentId: "876" },
    { id: "12348", trimester: 1, year: "2021-2022", date: "15/12/2021", studentId: "123" },
    { id: "12349", trimester: 2, year: "2021-2022", date: "15/03/2022", studentId: "123" },
  ]

  // Filter reports based on user role and studentId
  const [filteredReports, setFilteredReports] = useState<ReportItem[]>([])

  useEffect(() => {
    if (user) {
      if (user.role === "student" && user.studentId) {
        // Students can only see their own reports
        setFilteredReports(allReports.filter((report) => report.studentId === user.studentId))
      } else if (user.role === "parent" && user.studentId) {
        // Parents can see their children's reports
        setFilteredReports(allReports.filter((report) => report.studentId === user.studentId))
      } else if (user.role === "teacher" || user.role === "admin") {
        // Teachers and admins can see all reports
        setFilteredReports(allReports)
      } else {
        setFilteredReports([])
      }
    } else {
      setFilteredReports([])
    }
  }, [user])

  const handleDownload = async (reportId: string) => {
    setIsDownloading(reportId)

    try {
      // Dynamically import jsPDF only when needed
      const { jsPDF } = await import("jspdf")
      await import("jspdf-autotable")

      // In a real app, you would fetch the report data based on the ID
      // For this example, we'll use the sample data
      downloadReportPDF(sampleReportData)
    } catch (error) {
      console.error("Error generating PDF:", error)
    } finally {
      setIsDownloading(null)
    }
  }

  return (
    <div className="container mx-auto p-4 md:p-6">
      <div className="mb-8">
        <h1 className="text-2xl font-bold">Bulletins de notes</h1>
        <p className="text-muted-foreground">
          {user?.role === "student"
            ? "Consultez vos bulletins scolaires"
            : user?.role === "parent"
              ? "Consultez les bulletins scolaires de votre enfant"
              : "Consultez les bulletins scolaires des élèves"}
        </p>
      </div>

      {filteredReports.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-muted-foreground">Aucun bulletin disponible.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredReports.map((report) => (
            <Card key={report.id}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5 text-blue-600" />
                  Bulletin du {report.trimester}er trimestre
                </CardTitle>
                <CardDescription>Année scolaire {report.year}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-sm space-y-2">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Date d'émission:</span>
                    <span>{report.date}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Élève:</span>
                    <span>{user?.name || "Rafael DUPOND"}</span>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex flex-col gap-2">
                <Link href={`/reports/${report.id}`} className="w-full">
                  <Button variant="outline" className="w-full">
                    Consulter
                  </Button>
                </Link>
                <Button
                  variant="secondary"
                  className="w-full flex items-center gap-2"
                  onClick={() => handleDownload(report.id)}
                  disabled={isDownloading !== null}
                >
                  <Download className="h-4 w-4" />
                  {isDownloading === report.id ? "Génération..." : "Télécharger"}
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}

