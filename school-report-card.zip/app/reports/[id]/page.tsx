"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/contexts/auth-context"
import { ReportCard } from "@/components/report-card"
import { sampleReportData } from "@/data/sample-report-data"
import { Loader2 } from "lucide-react"

interface ReportPageProps {
  params: {
    id: string
  }
}

export default function ReportPage({ params }: ReportPageProps) {
  const { user } = useAuth()
  const router = useRouter()
  const [isAuthorized, setIsAuthorized] = useState<boolean | null>(null)

  // In a real application, you would fetch data based on the ID
  // For demo purposes, we're using the sample data
  const reportData = sampleReportData

  // Check if the user is authorized to view this report
  useEffect(() => {
    if (!user) {
      setIsAuthorized(false)
      return
    }

    // Mock authorization check
    // In a real app, you would check if the report belongs to the student or their parent
    if (user.role === "student" || user.role === "parent") {
      // Check if the report belongs to the student
      // For this example, we'll assume reports with IDs 12345, 12346, 12347 belong to student with ID 876
      const studentReports = ["12345", "12346", "12347"]
      const reportBelongsToStudent = user.studentId === "876" && studentReports.includes(params.id)

      setIsAuthorized(reportBelongsToStudent)

      // Redirect if not authorized
      if (!reportBelongsToStudent) {
        router.push("/unauthorized")
      }
    } else if (user.role === "teacher" || user.role === "admin") {
      // Teachers and admins can view all reports
      setIsAuthorized(true)
    } else {
      setIsAuthorized(false)
    }
  }, [user, params.id, router])

  // Show loading state
  if (isAuthorized === null) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="flex flex-col items-center gap-2">
          <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
          <p className="text-sm text-muted-foreground">Chargement...</p>
        </div>
      </div>
    )
  }

  // If authorized, show the report
  return (
    <main className="min-h-screen bg-gray-100 p-2 md:py-8">
      <ReportCard data={reportData} />
    </main>
  )
}

