"use client"

import { useAuth } from "@/contexts/auth-context"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { BookOpen, Calendar, FileText, MessageSquare, Settings, Users } from "lucide-react"

export default function DashboardPage() {
  const { user } = useAuth()

  return (
    <div className="container mx-auto p-4 md:p-6">
      <div className="mb-8">
        <h1 className="text-2xl font-bold">Tableau de bord</h1>
        <p className="text-muted-foreground">Bienvenue, {user?.name || user?.username}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5 text-blue-600" />
              Bulletins de notes
            </CardTitle>
            <CardDescription>Consultez vos bulletins scolaires</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm mb-4">Accédez à vos bulletins de notes pour chaque trimestre.</p>
            <Link href="/reports">
              <Button variant="outline" className="w-full">
                Voir mes bulletins
              </Button>
            </Link>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5 text-blue-600" />
              Emploi du temps
            </CardTitle>
            <CardDescription>Consultez votre planning</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm mb-4">Accédez à votre emploi du temps et aux événements à venir.</p>
            <Button variant="outline" className="w-full">
              Voir mon planning
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2">
              <BookOpen className="h-5 w-5 text-blue-600" />
              Devoirs
            </CardTitle>
            <CardDescription>Suivez vos devoirs et travaux</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm mb-4">Consultez les devoirs à faire et les dates de rendu.</p>
            <Button variant="outline" className="w-full">
              Voir mes devoirs
            </Button>
          </CardContent>
        </Card>

        {user?.role === "teacher" && (
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5 text-blue-600" />
                Mes classes
              </CardTitle>
              <CardDescription>Gérez vos classes et élèves</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm mb-4">Accédez à la liste de vos classes et élèves.</p>
              <Button variant="outline" className="w-full">
                Gérer mes classes
              </Button>
            </CardContent>
          </Card>
        )}

        {user?.role === "admin" && (
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5 text-blue-600" />
                Administration
              </CardTitle>
              <CardDescription>Gérez les utilisateurs et les classes</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm mb-4">Accédez au panneau d'administration.</p>
              <Link href="/admin">
                <Button variant="outline" className="w-full">
                  Administration
                </Button>
              </Link>
            </CardContent>
          </Card>
        )}

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2">
              <MessageSquare className="h-5 w-5 text-blue-600" />
              Messages
            </CardTitle>
            <CardDescription>Communications et annonces</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm mb-4">Consultez les messages et annonces de l'établissement.</p>
            <Button variant="outline" className="w-full">
              Voir les messages
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

