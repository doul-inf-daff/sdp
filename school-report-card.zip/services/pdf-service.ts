import type { ReportCardData } from "@/types/report-card"
import { jsPDF } from "jspdf"
import "jspdf-autotable"

// Add the autotable plugin to the jsPDF type
declare module "jspdf" {
  interface jsPDF {
    autoTable: (options: any) => jsPDF
  }
}

export const generateReportPDF = (data: ReportCardData): jsPDF => {
  // Create a new PDF document
  const doc = new jsPDF()

  // Add school header
  doc.setFontSize(20)
  doc.setTextColor(0, 102, 204)
  doc.text("MyScol", 14, 20)

  doc.setFontSize(10)
  doc.setTextColor(100, 100, 100)
  doc.text(
    [
      data.schoolName,
      data.schoolAddress,
      `${data.schoolZip} ${data.schoolCity}`,
      `Tél: ${data.schoolPhone} - Site: ${data.schoolWebsite}`,
    ],
    14,
    30,
  )

  // Add report title
  doc.setFontSize(16)
  doc.setTextColor(0, 0, 0)
  doc.text(`BULLETIN DE NOTES DU ${data.trimester === 1 ? "1ER" : `${data.trimester}ÈME`} TRIMESTRE`, 105, 50, {
    align: "center",
  })
  doc.setFontSize(12)
  doc.text(`Année scolaire: ${data.schoolYear}`, 105, 58, { align: "center" })

  // Add student info
  doc.setFontSize(11)
  doc.text(`Nom: ${data.student.lastName} ${data.student.firstName}`, 14, 70)
  doc.text(`Classe: ${data.student.class} (${data.student.classSize} élèves)`, 14, 78)
  doc.text(
    `Section: ${data.student.section} (${data.student.sectionSize} élève${data.student.sectionSize > 1 ? "s" : ""})`,
    120,
    70,
  )

  // Add grades table
  const tableColumn = ["Matière", "Moy /20", "Min", "Max", "Moy Classe", "Appréciations"]
  const tableRows = data.subjects.map((subject) => [
    `${subject.name}\n${subject.teacher.title} ${subject.teacher.name}`,
    subject.studentGrade.toFixed(2),
    subject.classMin.toFixed(2),
    subject.classMax.toFixed(2),
    subject.classAverage.toFixed(2),
    subject.comments,
  ])

  doc.autoTable({
    head: [tableColumn],
    body: tableRows,
    startY: 85,
    styles: { fontSize: 9, cellPadding: 3 },
    columnStyles: {
      0: { cellWidth: 40 },
      1: { cellWidth: 15, halign: "center" },
      2: { cellWidth: 15, halign: "center" },
      3: { cellWidth: 15, halign: "center" },
      4: { cellWidth: 15, halign: "center" },
      5: { cellWidth: "auto" },
    },
    alternateRowStyles: { fillColor: [240, 240, 240] },
    headStyles: { fillColor: [51, 71, 91], textColor: 255 },
  })

  // Get the Y position after the table
  const finalY = (doc as any).lastAutoTable.finalY + 10

  // Add summary section
  doc.setFillColor(51, 71, 91)
  doc.setTextColor(255, 255, 255)

  // Summary headers
  doc.rect(14, finalY, 85, 10, "F")
  doc.rect(105, finalY, 85, 10, "F")
  doc.text("Moyenne générale", 20, finalY + 6)
  doc.text("Nombre de demi-journée d'absence", 110, finalY + 6)

  // Summary values
  doc.setTextColor(0, 0, 0)
  doc.rect(14, finalY + 10, 85, 10)
  doc.rect(105, finalY + 10, 85, 10)
  doc.text(data.generalAverage.toFixed(2), 56, finalY + 16, { align: "center" })
  doc.text(data.absences.toString(), 147, finalY + 16, { align: "center" })

  // Add final comments section
  doc.setFillColor(51, 71, 91)
  doc.setTextColor(255, 255, 255)

  // Comments headers
  doc.rect(14, finalY + 25, 85, 10, "F")
  doc.rect(105, finalY + 25, 85, 10, "F")
  doc.text("Mention", 20, finalY + 31)
  doc.text("Appréciations du conseil de classe", 110, finalY + 31)

  // Comments values
  doc.setTextColor(0, 0, 0)
  doc.rect(14, finalY + 35, 85, 25)
  doc.rect(105, finalY + 35, 85, 25)
  doc.text(data.mention, 56, finalY + 47, { align: "center" })

  // Split long comments into multiple lines
  const splitComments = doc.splitTextToSize(data.councilComments, 75)
  doc.text(splitComments, 110, finalY + 41)

  // Add footer
  doc.setFontSize(8)
  doc.setTextColor(100, 100, 100)
  doc.text(`Document généré le ${new Date().toLocaleDateString("fr-FR")} - MyScol`, 105, 285, { align: "center" })

  return doc
}

export const downloadReportPDF = (data: ReportCardData) => {
  const doc = generateReportPDF(data)

  // Generate filename
  const filename = `bulletin_${data.student.lastName.toLowerCase()}_${data.student.firstName.toLowerCase()}_${data.trimester}T_${data.schoolYear.replace("-", "_")}.pdf`

  // Download the PDF
  doc.save(filename)
}

