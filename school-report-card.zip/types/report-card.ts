// Define types for our report card data
export interface Teacher {
  name: string
  title: string // Mme, M., etc.
}

export interface Subject {
  name: string
  coefficient: number
  teacher: Teacher
  studentGrade: number
  classMin: number
  classMax: number
  classAverage: number
  comments: string
}

export interface Student {
  id: string
  firstName: string
  lastName: string
  class: string
  classSize: number
  section: string
  sectionSize: number
  avatarUrl: string
}

export interface ReportCardData {
  student: Student
  schoolYear: string
  trimester: number
  subjects: Subject[]
  generalAverage: number
  absences: number
  mention: string
  councilComments: string
  schoolName: string
  schoolAddress: string
  schoolCity: string
  schoolZip: string
  schoolPhone: string
  schoolWebsite: string
}

