// User type definitions
export type UserRole = "student" | "teacher" | "parent" | "admin"

export interface ChildReference {
  id: string
  name: string
}

export interface User {
  id: string
  name: string
  username: string
  email?: string
  role: UserRole

  // Student specific properties
  studentId?: string
  class?: string
  section?: string

  // Teacher specific properties
  assignedClasses?: string[]
  subjects?: string[]

  // Parent specific properties
  children?: ChildReference[]
}

