import Image from "next/image"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

export default function ReportCard() {
  return (
    <div className="max-w-4xl mx-auto bg-white shadow-md">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:justify-between md:items-center p-4 border-b">
        <div className="flex items-center gap-2 mb-4 md:mb-0">
          <div className="w-12 h-12 relative">
            <Image
              src="/placeholder.svg?height=48&width=48"
              alt="MyScol Logo"
              width={48}
              height={48}
              className="object-contain"
            />
          </div>
          <h1 className="text-2xl font-bold text-blue-500">MyScol</h1>
        </div>
        <div className="text-left md:text-right text-sm">
          <p className="font-semibold">Institut Privé collège - lycée</p>
          <p>Adresse</p>
          <p>75008 PARIS</p>
          <p>Tél: 0123456789 - Site: demo.myscol.net</p>
        </div>
      </div>

      {/* Title */}
      <div className="text-center py-4 md:py-6 border-b px-2">
        <h2 className="text-xl md:text-2xl font-bold">BULLETIN DE NOTES DU 1ER TRIMESTRE</h2>
        <p className="mt-1 text-sm md:text-base">Année scolaire: 2021-2022</p>
      </div>

      {/* Student Info */}
      <div className="flex flex-col md:flex-row md:justify-between p-4 border-b">
        <div className="space-y-2 md:space-y-4 mb-4 md:mb-0">
          <div className="flex gap-2">
            <p className="font-bold">Nom :</p>
            <p>DUPOND Rafael</p>
          </div>
          <div className="flex gap-2">
            <p className="font-bold">Classe :</p>
            <p>3EME (2 élèves)</p>
          </div>
        </div>
        <div className="flex flex-col md:items-end">
          <div className="flex gap-2 mb-4">
            <p className="font-bold">Section :</p>
            <p>3ème LV2 Allemand (1 élève)</p>
          </div>
          <div className="w-20 h-20 md:w-24 md:h-24 relative self-center md:self-end">
            <Image
              src="/placeholder.svg?height=96&width=96"
              alt="Student Avatar"
              width={96}
              height={96}
              className="object-contain"
            />
          </div>
        </div>
      </div>

      {/* Grades Table - Scrollable on mobile */}
      <div className="overflow-x-auto">
        <Table>
          <TableHeader className="bg-slate-700 text-white">
            <TableRow>
              <TableHead className="w-1/4 py-3 whitespace-nowrap">Matières</TableHead>
              <TableHead className="w-1/12 text-center py-3 whitespace-nowrap">Moy /20</TableHead>
              <TableHead colSpan={3} className="text-center py-3 whitespace-nowrap">
                Classe
              </TableHead>
              <TableHead className="w-1/2 py-3">Appréciations</TableHead>
            </TableRow>
            <TableRow className="bg-slate-700 text-white">
              <TableHead></TableHead>
              <TableHead></TableHead>
              <TableHead className="text-center py-2 whitespace-nowrap">Min</TableHead>
              <TableHead className="text-center py-2 whitespace-nowrap">Max</TableHead>
              <TableHead className="text-center py-2 whitespace-nowrap">Moy</TableHead>
              <TableHead></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            <TableRow className="bg-gray-100">
              <TableCell className="font-medium">
                <span className="whitespace-nowrap">
                  Français <sup>(1)</sup>
                </span>
                <div className="text-xs md:text-sm italic">Mme PONOMAROVA</div>
              </TableCell>
              <TableCell className="text-center">17.75</TableCell>
              <TableCell className="text-center">15.00</TableCell>
              <TableCell className="text-center">17.75</TableCell>
              <TableCell className="text-center">16.38</TableCell>
              <TableCell className="text-xs md:text-sm">
                Excellent trimestre, fruit d'un travail consciencieux et de qualité. Continue à t'impliquer avec la même
                méthode efficace ! Félicitations !
              </TableCell>
            </TableRow>
            <TableRow>
              <TableCell className="font-medium">
                <span className="whitespace-nowrap">
                  Histoire Géographie <sup>(1)</sup>
                </span>
                <div className="text-xs md:text-sm italic">M. MARTRON</div>
              </TableCell>
              <TableCell className="text-center">17.33</TableCell>
              <TableCell className="text-center">16.50</TableCell>
              <TableCell className="text-center">17.33</TableCell>
              <TableCell className="text-center">16.92</TableCell>
              <TableCell className="text-xs md:text-sm">
                Élève très sérieux et impliqué, Rafael a le souci de bien faire, ses travaux sont d'une grande qualité!
                Ensemble très satisfaisant
              </TableCell>
            </TableRow>
            <TableRow className="bg-gray-100">
              <TableCell className="font-medium">
                <span className="whitespace-nowrap">
                  LV1 ANGLAIS <sup>(1)</sup>
                </span>
                <div className="text-xs md:text-sm italic">Mme ROZAND</div>
              </TableCell>
              <TableCell className="text-center">17.64</TableCell>
              <TableCell className="text-center">16.07</TableCell>
              <TableCell className="text-center">17.64</TableCell>
              <TableCell className="text-center">16.86</TableCell>
              <TableCell className="text-xs md:text-sm">
                Très bon ensemble. Élève sérieux et motivé. Il faut continuer ainsi.
              </TableCell>
            </TableRow>
            <TableRow>
              <TableCell className="font-medium">
                <span className="whitespace-nowrap">
                  LV2 ALLEMAND <sup>(1)</sup>
                </span>
                <div className="text-xs md:text-sm italic">Mme ROZAND</div>
              </TableCell>
              <TableCell className="text-center">19.00</TableCell>
              <TableCell className="text-center">19.00</TableCell>
              <TableCell className="text-center">19.00</TableCell>
              <TableCell className="text-center">19.00</TableCell>
              <TableCell className="text-xs md:text-sm">
                Excellent trimestre. Travail très sérieux en grande autonomie. Bravo !
              </TableCell>
            </TableRow>
            <TableRow className="bg-gray-100">
              <TableCell className="font-medium">
                <span className="whitespace-nowrap">
                  Mathématiques <sup>(1)</sup>
                </span>
                <div className="text-xs md:text-sm italic">Mme BOUTIN</div>
              </TableCell>
              <TableCell className="text-center">19.47</TableCell>
              <TableCell className="text-center">16.01</TableCell>
              <TableCell className="text-center">19.47</TableCell>
              <TableCell className="text-center">17.74</TableCell>
              <TableCell className="text-xs md:text-sm">
                Excellent trimestre. Élève appliqué, précis et attentif en classe. Continue ainsi.
              </TableCell>
            </TableRow>
            <TableRow>
              <TableCell className="font-medium">
                <span className="whitespace-nowrap">
                  Sciences Physiques <sup>(1)</sup>
                </span>
                <div className="text-xs md:text-sm italic">Mme BERTRAND LEROUX</div>
              </TableCell>
              <TableCell className="text-center">18.14</TableCell>
              <TableCell className="text-center">17.71</TableCell>
              <TableCell className="text-center">18.14</TableCell>
              <TableCell className="text-center">17.93</TableCell>
              <TableCell className="text-xs md:text-sm">
                Excellent trimestre, Rafaël se montre motivé et intéressé par la matière. Son travail est de qualité et
                sa participation pertinente. Bravo Rafaël !
              </TableCell>
            </TableRow>
            <TableRow className="bg-gray-100">
              <TableCell className="font-medium">
                <span className="whitespace-nowrap">
                  SVT <sup>(1)</sup>
                </span>
                <div className="text-xs md:text-sm italic">Mme ROUBY</div>
              </TableCell>
              <TableCell className="text-center">17.00</TableCell>
              <TableCell className="text-center">17.00</TableCell>
              <TableCell className="text-center">18.00</TableCell>
              <TableCell className="text-center">17.50</TableCell>
              <TableCell className="text-xs md:text-sm">
                C'est un excellent trimestre ! Je félicite Rafael pour son sérieux, sa volonté et son dynamisme en
                classe.
              </TableCell>
            </TableRow>
            <TableRow>
              <TableCell className="font-medium">
                <span className="whitespace-nowrap">
                  Technologie <sup>(1)</sup>
                </span>
                <div className="text-xs md:text-sm italic">Mme BOUTIN</div>
              </TableCell>
              <TableCell className="text-center">16.00</TableCell>
              <TableCell className="text-center">14.50</TableCell>
              <TableCell className="text-center">16.00</TableCell>
              <TableCell className="text-center">15.25</TableCell>
              <TableCell className="text-xs md:text-sm">Excellent trimestre</TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </div>

      <div className="text-xs p-2 border-t">
        <sup>(1)</sup> : Coefficient de la matière
      </div>

      {/* Summary - Stack on mobile */}
      <div className="grid grid-cols-1 md:grid-cols-2 border-t">
        <div className="md:border-r p-3 md:p-4 flex justify-between items-center bg-slate-700 text-white">
          <span className="font-semibold text-sm md:text-base">Moyenne générale</span>
        </div>
        <div className="p-3 md:p-4 flex justify-between items-center bg-slate-700 text-white border-t md:border-t-0">
          <span className="font-semibold text-sm md:text-base">Nombre de demi-journée d'absence</span>
        </div>
        <div className="md:border-r p-3 md:p-4 text-center font-bold border-t">17.79</div>
        <div className="p-3 md:p-4 text-center font-bold border-t">0</div>
      </div>

      {/* Final Comments - Stack on mobile */}
      <div className="grid grid-cols-1 md:grid-cols-2 border-t">
        <div className="md:border-r p-3 md:p-4 flex justify-between items-center bg-slate-700 text-white">
          <span className="font-semibold text-sm md:text-base">Mention</span>
        </div>
        <div className="p-3 md:p-4 flex justify-between items-center bg-slate-700 text-white border-t md:border-t-0">
          <span className="font-semibold text-sm md:text-base">Appréciations du conseil de classe</span>
        </div>
        <div className="md:border-r p-3 md:p-4 text-center font-bold border-t">Félicitations</div>
        <div className="p-3 md:p-4 text-xs md:text-sm border-t">
          Excellent trimestre pour Rafael. Au delà de ses très bons résultats homogènes, Rafael fait preuve d'une
          maturité et d'une autonomie très favorables à la poursuite de sa réussite académique. Bravo !
        </div>
      </div>
    </div>
  )
}

